# __init__.py
from EPmodel import *  

